# Among Us Private Test Android

This is a native Android Studio **companion prototype**, not a game mod.

## Included
- Role selector UI: Regular Impostor, Shapeshifter, Phantom, Viper (demo selection only)
- ESP-style player list with randomly generated demo labels
- MedBay-style progress animation (visual simulation only)

## Not included
- No injection, memory reading, process access, network interception, anti-cheat bypass, or modification of Among Us
- Cannot reveal real hidden roles, change the role assigned by the game, or complete an in-game task

The supplied `OffsetGuide.md` describes old Windows/Mono memory-offset discovery. It does not contain Android offsets or a supported Android modding interface.

## Build
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Allow Gradle sync to finish (Android Studio may download the Android Gradle Plugin and SDK).
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press **Run**.

Minimum Android version: Android 6.0 (API 23). Compile SDK: 35.
