# Among Us Private Test Android
Standalone Android companion prototype with a movable floating panel.
Includes simulated role selector, sample player labels, visual scan demo, and a draggable overlay after the user grants Android's Display over other apps permission.
It does not inspect, modify, or connect to Among Us; it cannot reveal real roles or change in-game roles. The supplied offset guide documents old Windows memory offsets, not Android integration.
Build using the included GitHub Actions workflow and download the APK artifact.
