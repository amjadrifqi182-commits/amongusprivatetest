package com.example.amongusprivatetest;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager wm; private View panel; private WindowManager.LayoutParams lp;
    private float downX,downY; private int startX,startY;
    @Override public void onCreate() {
        super.onCreate();
        if(Build.VERSION.SDK_INT>=23 && !android.provider.Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); build();
    }
    private void build(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(14,12,14,12);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(0xff121b2e); bg.setCornerRadius(22); bg.setStroke(2,0xff4e8bdc); box.setBackground(bg);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label("🚀 PRIVATE TEST MENU",14,Color.WHITE,true); head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=label("×",24,Color.WHITE,true); head.addView(close); box.addView(head);
        box.addView(label("DEMO OVERLAY · simulated data only",10,0xffaab9d3,false));
        box.addView(label("Roles: Regular / Shapeshifter / Phantom / Viper",12,0xffdce8ff,true));
        box.addView(label("Player ESP: sample labels only",12,0xff9cf0c9,true));
        box.addView(label("MedBay scan: visual demo only",12,0xff9fd4ff,true));
        close.setOnClickListener(v->stopSelf());
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START; lp.x=24; lp.y=180;
        head.setOnTouchListener((v,e)->{switch(e.getAction()){
            case MotionEvent.ACTION_DOWN: downX=e.getRawX();downY=e.getRawY();startX=lp.x;startY=lp.y;return true;
            case MotionEvent.ACTION_MOVE: lp.x=startX+(int)(e.getRawX()-downX);lp.y=startY+(int)(e.getRawY()-downY);wm.updateViewLayout(panel,lp);return true;
        }return false;});
        panel=box; wm.addView(panel,lp);
    }
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(5,5,5,5);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    @Override public void onDestroy(){super.onDestroy();if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}}
    @Override public IBinder onBind(Intent i){return null;}
}
