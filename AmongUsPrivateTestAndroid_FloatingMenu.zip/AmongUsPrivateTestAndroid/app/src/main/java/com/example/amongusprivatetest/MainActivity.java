package com.example.amongusprivatetest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Random;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(11,16,32);
    private final int PANEL = Color.rgb(21,29,49);
    private final int MUTED = Color.rgb(154,168,194);
    private final int BLUE = Color.rgb(52,121,212);
    private final String[] roles = {"Regular Impostor", "Shapeshifter", "Phantom", "Viper"};
    private final String[] names = {"Red","Cyan","Yellow","Purple","Green","Orange","Pink","White","Lime","Blue"};
    private final int[] colors = {0xffe84c55,0xff56b7e9,0xffe7c34e,0xffb18be8,0xff55c78d,0xfff09b50,0xfff18fc1,0xffdce6ef,0xff8eaa58,0xff6f9ee8};
    private String selectedRole = roles[0];
    private TextView roleStatus, scanStatus, scanPercent;
    private ProgressBar scanProgress;
    private LinearLayout playerList;
    private int scanValue = 0;
    private boolean scanning = false;
    private final HandlerHolder handler = new HandlerHolder();

    private static class HandlerHolder {
        android.os.Handler h = new android.os.Handler();
        Runnable task;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(22), dp(16), dp(30));
        scroll.addView(page);
        setContentView(scroll);

        TextView title = text("🚀  Among Us · Private Test", 23, Color.WHITE, true);
        page.addView(title);
        page.addView(text("Android companion prototype · simulated data only", 12, MUTED, false));
        page.addView(space(16));

        LinearLayout overlayPanel = panel(page, "FLOATING COMPANION MENU");
        overlayPanel.addView(text("Movable demo panel that can appear over other apps. Simulated information only.", 12, MUTED, false));
        Button overlayButton = button("Enable floating menu");
        overlayPanel.addView(overlayButton);
        overlayButton.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else startService(new Intent(this, FloatingPanelService.class));
        });

        LinearLayout rolePanel = panel(page, "IMPOSTOR ROLE SELECTOR");
        TextView hint = text("Choose a role for this demo panel:", 13, MUTED, false);
        rolePanel.addView(hint);
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        spinner.setAdapter(adapter);
        rolePanel.addView(spinner);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                selectedRole = roles[pos];
                if (roleStatus != null) roleStatus.setText("Selected: " + selectedRole + ". Demo only; does not change your in-game role.");
            }
        });
        Button apply = button("Set demo role");
        rolePanel.addView(apply);
        roleStatus = text("Selected: Regular Impostor. Demo only; does not change your in-game role.", 12, MUTED, false);
        rolePanel.addView(roleStatus);
        apply.setOnClickListener(v -> roleStatus.setText("Demo role set to " + selectedRole + ". No game connection."));
        Button random = button("Random role");
        rolePanel.addView(random);
        random.setOnClickListener(v -> {
            int index = new Random().nextInt(roles.length);
            spinner.setSelection(index);
            selectedRole = roles[index];
            roleStatus.setText("Demo role set to " + selectedRole + ". No game connection.");
        });

        LinearLayout espPanel = panel(page, "ESP-STYLE PLAYER LIST");
        espPanel.addView(text("Example lobby. These labels are randomly simulated, not read from Among Us.", 12, MUTED, false));
        playerList = new LinearLayout(this);
        playerList.setOrientation(LinearLayout.VERTICAL);
        espPanel.addView(playerList);
        Button shuffle = button("Shuffle demo lobby");
        espPanel.addView(shuffle);
        shuffle.setOnClickListener(v -> populatePlayers());
        populatePlayers();

        LinearLayout scanPanel = panel(page, "MEDBAY SCAN ANIMATION");
        scanPanel.addView(text("Visual-only scan simulation. It does not perform or complete an in-game task.", 12, MUTED, false));
        scanStatus = text("Scanner idle", 18, Color.WHITE, true);
        scanStatus.setGravity(Gravity.CENTER);
        scanPanel.addView(scanStatus);
        scanProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        scanProgress.setMax(100);
        scanProgress.setProgress(0);
        scanPanel.addView(scanProgress);
        scanPercent = text("0%", 13, MUTED, false);
        scanPercent.setGravity(Gravity.CENTER);
        scanPanel.addView(scanPercent);
        Button start = button("Start demo scan");
        scanPanel.addView(start);
        Button reset = button("Reset scan");
        scanPanel.addView(reset);
        start.setOnClickListener(v -> startScan(start));
        reset.setOnClickListener(v -> {
            if (handler.task != null) handler.h.removeCallbacks(handler.task);
            scanning = false; scanValue = 0; scanProgress.setProgress(0);
            scanPercent.setText("0%"); scanStatus.setText("Scanner idle"); start.setEnabled(true);
        });

        page.addView(space(12));
        TextView disclaimer = text("IMPORTANT: This is a standalone companion demo. It does not inject into, modify, inspect, or connect to Among Us. Your supplied OffsetGuide.md describes old Windows memory offsets and does not provide Android integration or role-changing support.", 11, MUTED, false);
        page.addView(disclaimer);
    }

    private void populatePlayers() {
        playerList.removeAllViews();
        boolean[] impostor = new boolean[names.length];
        Random r = new Random();
        impostor[r.nextInt(names.length)] = true;
        impostor[r.nextInt(names.length)] = true;
        for (int i=0;i<names.length;i++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10),dp(9),dp(10),dp(9));
            row.setBackground(round(Color.rgb(16,24,42), 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(6);
            playerList.addView(row, lp);
            TextView dot = text("●", 17, colors[i], true);
            row.addView(dot);
            TextView name = text("  " + names[i], 14, Color.WHITE, true);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,-2,1);
            row.addView(name,nlp);
            TextView tag = text(impostor[i] ? "IMPOSTOR · DEMO" : "CREWMATE · DEMO", 10,
                    impostor[i] ? 0xffff9ba3 : 0xff9cf0c9, true);
            row.addView(tag);
        }
    }

    private void startScan(Button start) {
        if (scanning) return;
        scanning = true; scanValue = 0; start.setEnabled(false);
        scanStatus.setText("Scanning…");
        handler.task = new Runnable() {
            public void run() {
                scanValue = Math.min(100, scanValue + 2);
                scanProgress.setProgress(scanValue);
                scanPercent.setText(scanValue + "%");
                if (scanValue >= 100) {
                    scanning = false; scanStatus.setText("Demo animation complete"); start.setEnabled(true);
                } else handler.h.postDelayed(this, 100);
            }
        };
        handler.h.post(handler.task);
    }

    private LinearLayout panel(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(14),dp(14),dp(14));
        box.setBackground(round(PANEL,18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.topMargin = dp(14);
        parent.addView(box,p);
        TextView h = text(heading, 13, 0xffbcd3f5, true);
        box.addView(h);
        box.addView(space(8));
        return box;
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(round(BLUE,12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.topMargin = dp(8); b.setLayoutParams(p);
        return b;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private View space(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
